import streamlit as st
import numpy as np
import faiss
import torch
from sentence_transformers import SentenceTransformer
from difflib import SequenceMatcher
from typing import List, Tuple, Dict, Counter as CounterType
from fuzzywuzzy import fuzz
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
import re

# ─── GLOBAL STYLES ─────────────────────────────────────────────────────────────
st.set_page_config(page_title="Khmer Name OCR Matcher", layout="wide", page_icon="")
st.markdown(
    """
    <style>
    .header {text-align: center; font-size: 2.5rem; font-weight: bold; margin-bottom: 1rem;}
    .subheader {font-size: 1.2rem; color: #555;}
    .card {background: #f9f9f9; padding: 1rem; border-radius: 8px; margin-bottom: 1rem;}
    .card-title {font-weight: bold; font-size: 1.1rem; color: #000;}
    .score {float: right; font-size: 0.9rem; color: #777;}
    .latin {color: #555; font-size: 0.9rem; margin-top: 0.2rem;}
    .combined-score {color: #007bff; font-weight: bold;}
    .freq {color: #28a745; font-size: 0.8rem; margin-left: 0.5rem;}
</style>
    """, unsafe_allow_html=True
)

# ─── MATCHER CLASS ─────────────────────────────────────────────────────────────
class KhmerNameMatcher:
    def __init__(self, names_file: str, model_name: str = "paraphrase-multilingual-mpnet-base-v2"):
        self.model = SentenceTransformer(model_name, device="cuda")
        self.names, self.latin_map, self.name_counts = self._load_names(names_file)
        self._build_index()
        self._build_tfidf()

    def _load_names(self, filename: str) -> Tuple[List[str], Dict[str, str], CounterType[str]]:
        raw_names: List[str] = []
        latin_map: Dict[str, str] = {}
        
        print(f"Loading names from: {filename}")
        
        with open(filename, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                
                # Expecting "Khmer,Latin"
                parts = line.split(',', 1)
                if len(parts) >= 2:
                    khmer = parts[0].strip()
                    latin = parts[1].strip().rstrip(',')
                    
                    if khmer and latin:
                        raw_names.append(khmer)
                        latin_map[khmer] = latin
                        
                        # Debug first few entries
                        if line_num <= 5:
                            print(f"Line {line_num}: Mapped Khmer '{khmer}' -> Latin '{latin}'")
                else:
                    # No comma or only one part: treat as Khmer-only
                    khmer_only = parts[0].strip()
                    raw_names.append(khmer_only)
                    
                    # Debug first few entries
                    if line_num <= 5:
                        print(f"Line {line_num}: Added Khmer-only '{khmer_only}'")
        
        # Count frequencies (keeping duplicates for statistics)
        name_counts = Counter(raw_names)
        unique_names = list(name_counts.keys())
        
        print(f"Loaded {len(raw_names)} Khmer names ({len(unique_names)} unique) and {len(latin_map)} Latin mappings")
        print(f"Top 5 most frequent names: {name_counts.most_common(5)}")
        
        return unique_names, latin_map, name_counts

    def _build_index(self):
        # Move computation to GPU and keep it there during encoding
        embeddings = self.model.encode(
            self.names,
            convert_to_tensor=True,
            device='cuda',  # <-- this is crucial
            show_progress_bar=True
        )

        # Move to CPU only after encoding
        emb_np = embeddings.detach().cpu().numpy()

        # Normalize for cosine similarity
        faiss.normalize_L2(emb_np)
        
        # Create and populate FAISS index
        dim = emb_np.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(emb_np)
    
    def _build_tfidf(self):
        """Build TF-IDF vectors for character n-grams in names"""
        # Tokenize names into character n-grams
        def char_ngrams(text, n_range=(1, 3)):
            text = text.lower()
            tokens = []
            for n in range(n_range[0], n_range[1] + 1):
                for i in range(len(text) - n + 1):
                    tokens.append(text[i:i+n])
            return " ".join(tokens)
        
        # Prepare corpus with character n-grams
        corpus = [char_ngrams(name) for name in self.names]
        
        # Build TF-IDF vectorizer
        self.tfidf = TfidfVectorizer(analyzer='word', ngram_range=(1, 1))
        self.tfidf_matrix = self.tfidf.fit_transform(corpus)
        
        print(f"Built TF-IDF matrix with shape: {self.tfidf_matrix.shape}")

    def match_name(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:
        q = query.strip()
        if not q:
            return []

        # GPU encoding
        emb = self.model.encode(
            [q],
            convert_to_tensor=True,
            device='cuda'  # GPU here
        )

        # Convert to NumPy for FAISS (FAISS is still on CPU)
        emb_np = emb.detach().cpu().numpy()
        faiss.normalize_L2(emb_np)

        # FAISS search
        scores, idxs = self.index.search(emb_np, min(top_k, len(self.names)))
        return [(self.names[i], float(scores[0][j])) for j, i in enumerate(idxs[0])]

    def keyword_search(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:
        if not query: return []
        scores = []
        qset = set(query)
        for name in self.names:
            nset = set(name)
            overlap = len(qset & nset)
            union = len(qset | nset) or 1
            scores.append((name, overlap/union))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]
    
    def tfidf_search(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:
        """Search using TF-IDF character n-grams"""
        if not query: return []
        
        # Tokenize query into character n-grams
        def char_ngrams(text, n_range=(1, 3)):
            text = text.lower()
            tokens = []
            for n in range(n_range[0], n_range[1] + 1):
                for i in range(len(text) - n + 1):
                    tokens.append(text[i:i+n])
            return " ".join(tokens)
        
        # Transform query to TF-IDF space
        query_ngrams = char_ngrams(query)
        query_tfidf = self.tfidf.transform([query_ngrams])
        
        # Calculate cosine similarity with all names
        similarities = (query_tfidf @ self.tfidf_matrix.T).toarray()[0]
        
        # Get top-k names
        results = [(self.names[i], float(similarities[i])) 
                   for i in np.argsort(similarities)[::-1][:top_k]]
        
        return results

    def hybrid_match(self, query: str, top_k: int = 5, semantic_weight: float = 0.6, 
                    tfidf_weight: float = 0.2) -> List[Tuple[str, float]]:
        """
        Combine semantic, TF-IDF, and keyword matching with frequency boosting
        """
        keyword_weight = 1.0 - semantic_weight - tfidf_weight
        
        sem = dict(self.match_name(query, top_k*2))
        kw = dict(self.keyword_search(query, top_k*2))
        tfidf = dict(self.tfidf_search(query, top_k*2))
        
        # Combine scores
        combined = {}
        for name_list, weight in [(sem, semantic_weight), 
                                 (tfidf, tfidf_weight), 
                                 (kw, keyword_weight)]:
            for name, score in name_list.items():
                if name not in combined:
                    combined[name] = 0
                combined[name] += score * weight
        
        # Apply frequency boost (logarithmic to avoid overpowering)
        for name in combined:
            freq = self.name_counts.get(name, 1)
            freq_boost = 1.0 + (0.1 * np.log1p(freq))  # Logarithmic boost
            combined[name] *= freq_boost
        
        return sorted(combined.items(), key=lambda x: x[1], reverse=True)[:top_k]
                
    def has_latin_names(self) -> bool:
        """Check if the loaded dataset has Latin name mappings"""
        return len(self.latin_map) > 0
    
    def get_latin_name(self, khmer_name: str) -> str:
        """Get the Latin transliteration for a Khmer name if available"""
        return self.latin_map.get(khmer_name, "")
    
    def get_name_frequency(self, name: str) -> int:
        """Get frequency count for a name"""
        return self.name_counts.get(name, 0)
    
    def match_with_latin_fallback(
        self,
        khmer_query: str,
        latin_query: str,
        top_k: int = 5,
        semantic_weight: float = 0.6,
        tfidf_weight: float = 0.2,
        latin_weight: float = 0.5
    ) -> List[Tuple[str, float, str, float, float, int]]:
        """
        Two-stage matching: first semantic+tfidf+keyword match on Khmer, then refine with Latin matching.
        Returns a list of tuples:
          (khmer_name, semantic_score, latin_name, combined_score, latin_score, frequency)
        """
        # 1) Semantic + TF-IDF + keyword on Khmer
        khmer_matches = self.hybrid_match(khmer_query, top_k * 10, semantic_weight, tfidf_weight)

        # --- DEBUG: Overview ---
        print(f"Khmer query: '{khmer_query}'")
        print(f"Latin query: '{latin_query}'")
        print(f"Has Latin names? {self.has_latin_names()} (map size = {len(self.latin_map)})")
        if self.latin_map:
            print("Sample Latin mappings:")
            for k in list(self.latin_map.keys())[:3]:
                print(f"  {k} -> {self.latin_map[k]}")
        print("-" * 50)

        # 2) If no Latin data or no Latin query, skip second stage
        if not latin_query or not self.has_latin_names():
            return [
                (name, score, self.get_latin_name(name), score, 0.0, self.get_name_frequency(name))
                for name, score in khmer_matches[:top_k]
            ]

        # 3) Refine each Khmer candidate by comparing Latin strings
        refined = []
        q = latin_query.lower().strip()
        for khmer_name, khmer_score in khmer_matches:
            latin_name = self.get_latin_name(khmer_name) or ""
            latin_score = 0.0
            frequency = self.get_name_frequency(khmer_name)

            print(f"Candidate Khmer: '{khmer_name}' → Latin: '{latin_name}' (Khmer score = {khmer_score:.3f}, Freq = {frequency})")

            if latin_name:
                t = latin_name.lower().strip()

                # 3a) Exact match shortcut
                if q == t:
                    latin_score = 1.0
                    print(f"  → EXACT MATCH, latin_score = 1.000")
                else:
                    # 3b) SequenceMatcher blocks
                    sm = SequenceMatcher(None, q, t)
                    matched_chars = sum(block.size for block in sm.get_matching_blocks())
                    max_len = max(len(q), len(t))
                    mismatches = max_len - matched_chars
                    latin_score = matched_chars / max_len
                    print(f"  → SeqMatch: matched={matched_chars}, max_len={max_len}, mismatches={mismatches}, score={latin_score:.3f}")

                    # 3c) FuzzyWuzzy for comparison (optional)
                    fuzzy = fuzz.ratio(q, t)
                    fuzzy_norm = fuzzy / 100.0
                    print(f"  → FuzzyWuzzy: ratio={fuzzy}/100 → {fuzzy_norm:.3f}")
                    # If you'd like to take the higher of the two:
                    # latin_score = max(latin_score, fuzzy_norm)

                # 3d) Combine Khmer & Latin with latin_weight
                combined = khmer_score * (1 - latin_weight) + latin_score * latin_weight
                
                # Apply frequency boost
                freq_boost = 1.0 + (0.1 * np.log1p(frequency))
                combined *= freq_boost
                print(f"  → Combined: {khmer_score:.3f}*(1−{latin_weight}) + {latin_score:.3f}*{latin_weight} * {freq_boost:.2f} = {combined:.3f}")

            else:
                combined = khmer_score
                print(f"  → No Latin mapping, combined = Khmer score = {combined:.3f}")

            refined.append((khmer_name, khmer_score, latin_name, combined, latin_score, frequency))
            print("-" * 30)

        # 4) Return top-K by combined score
        refined.sort(key=lambda x: x[3], reverse=True)
        return refined[:top_k]

# ─── DATA LOADING & CACHE ──────────────────────────────────────────────────────
@st.cache_resource
def load_matcher(names_path: str):
    return KhmerNameMatcher(names_path)

# ─── UI LAYOUT ─────────────────────────────────────────────────────────────────
st.markdown("<div class='header'>Khmer Name OCR Corrector</div>", unsafe_allow_html=True)
st.markdown("<div class='subheader'>Upload a names file to begin. For best results, include Latin transliterations.</div>", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.header("⚙️ Configuration")
    uploaded = st.file_uploader("Khmer Names File", type=["txt", "csv"], 
                               help="Format: 'khmer_name,latin_name' on each line for best results")
    if uploaded:
        names_path = "khmer_names_temp.txt"
        with open(names_path, 'wb') as f: f.write(uploaded.getvalue())
        matcher = load_matcher(names_path)
        st.success(f"✅ Loaded **{len(matcher.names)}** unique names")
        total_with_dups = sum(matcher.name_counts.values())
        st.success(f"✅ Total entries with duplicates: **{total_with_dups}**")
        if matcher.has_latin_names():
            st.success(f"✅ Latin transliterations available")
        else:
            st.warning("No Latin transliterations found. Add them for better results.")
        
        # Show most frequent names
        st.subheader("Most Common Names")
        for name, count in matcher.name_counts.most_common(5):
            latin = matcher.get_latin_name(name) or ""
            if latin:
                st.write(f"**{name}** ({latin}): {count}")
            else:
                st.write(f"**{name}**: {count}")
    else:
        matcher = None
        st.warning("Please upload a names file.")

    st.subheader("Match Settings")
    top_k = st.slider("Top K Results", 1, 10, 5)
    semantic_weight = st.slider("Semantic Weight", 0.0, 1.0, 0.6,
                               help="Weight for semantic matching")
    tfidf_weight = st.slider("TF-IDF Weight", 0.0, 1.0, 0.2,
                            help="Weight for TF-IDF matching")
    
    if semantic_weight + tfidf_weight > 1.0:
        st.warning("Total weight exceeds 1.0. Remaining weight will be capped.")
        tfidf_weight = min(tfidf_weight, 1.0 - semantic_weight)
    
    keyword_weight = 1.0 - semantic_weight - tfidf_weight
    st.info(f"Keyword Weight: {keyword_weight:.2f}")
    
    use_latin = st.checkbox("Use Latin/English matching", value=True)
    latin_weight = st.slider("Latin Match Weight", 0.0, 1.0, 0.5,
                           help="Weight of Latin name matching vs. Khmer matching")
    
    st.markdown("---")
    st.markdown("Need help? [GitHub Repo](#) | [Docs](#)")

# Main Input / Output
col1, col2 = st.columns((2,3), gap="large")
with col1:
    st.subheader("🔡 Enter OCR Text")
    if not matcher:
        st.info("Upload a names file in the sidebar to enable matching.")
    else:
        ocr_input_khmer = st.text_area("Paste Khmer OCR text (one name per line)", height=150,
                                 placeholder="e.g. លឹមហ៊ន")
        
        ocr_input_latin = st.text_area("Paste Latin/English OCR text (one name per line)", height=100,
                                     placeholder="e.g. Lim Hun", 
                                     disabled=not use_latin)
        
        if st.button("🔍 Match Names", type="primary"):
            if not ocr_input_khmer.strip():
                st.warning("Please enter some Khmer OCR text above.")
            else:
                khmer_lines = [l for l in ocr_input_khmer.splitlines() if l.strip()]
                latin_lines = [l for l in ocr_input_latin.splitlines() if l.strip()] if use_latin else []
                
                # Ensure same number of lines for both inputs if Latin is used
                if use_latin and len(latin_lines) != len(khmer_lines):
                    st.error(f"Number of Latin names ({len(latin_lines)}) doesn't match Khmer names ({len(khmer_lines)})")
                else:
                    # Match each name
                    results = {}
                    for i, khmer in enumerate(khmer_lines):
                        # Get corresponding Latin name if available
                        latin = ""
                        if use_latin and i < len(latin_lines):
                            latin = latin_lines[i].strip()
                        
                        # Show debug info above each match
                        if use_latin:
                            st.markdown(f"**Debug - Processing:**")
                            st.markdown(f"* Khmer input: `{khmer}`")
                            st.markdown(f"* Latin input: `{latin}`")
                        
                        if use_latin and matcher.has_latin_names() and latin:
                            st.markdown("Using Latin+Khmer matching")
                            results[khmer] = matcher.match_with_latin_fallback(
                                khmer, latin, top_k, semantic_weight, tfidf_weight, latin_weight
                            )
                        else:
                            if use_latin:
                                st.markdown("Falling back to Khmer-only matching")
                            khmer_matches = matcher.hybrid_match(khmer, top_k, semantic_weight, tfidf_weight)
                            results[khmer] = [
                                (name, score, matcher.get_latin_name(name), score, 0.0, matcher.get_name_frequency(name)) 
                                for name, score in khmer_matches
                            ]
                    st.session_state["results"] = results
                    st.session_state["use_latin"] = use_latin

with col2:
    st.subheader("📊 Results")
    if "results" in st.session_state:
        for line, matches in st.session_state["results"].items():
            st.markdown(f"**OCR Input:** `{line}`")
            for khmer_name, khmer_score, latin_name, combined_score, latin_score, frequency in matches:
                # Display the matched name with scores
                # Ensure no trailing commas in display names
                display_name = khmer_name.rstrip(',')
                
                freq_html = f"<span class='freq'>({frequency} occurrences)</span>" if frequency > 1 else ""
                
                if st.session_state.get("use_latin") and latin_name:
                    st.markdown(
                        f"<div class='card'>"
                        f"<span class='card-title'>{display_name}</span>{freq_html}"
                        f"<div class='latin'>{latin_name}</div>"
                        f"<span class='score'>Khmer: {khmer_score:.3f}</span><br>"
                        f"<span class='score'>Latin: {latin_score:.3f}</span><br>"
                        f"<span class='combined-score'>Combined: {combined_score:.3f}</span>"
                        f"</div>",
                        unsafe_allow_html=True
                    )
                else:
                    # Create score displays without the Latin name
                    latin_score_html = ""
                    if latin_score > 0:
                        latin_score_html = f"<span class='score'>Latin: {latin_score:.3f}</span><br>"
                    
                    latin_html = f"<div class='latin'>{latin_name}</div>" if latin_name else ""
                    
                    st.markdown(
                        f"<div class='card'>"
                        f"<span class='card-title'>{display_name}</span>{freq_html}"
                        f"{latin_html}"
                        f"<span class='score'>Khmer: {khmer_score:.3f}</span><br>"
                        f"{latin_score_html}"
                        f"<span class='combined-score'>Combined: {combined_score:.3f}</span>"
                        f"</div>",
                        unsafe_allow_html=True
                    )
    else:
        st.info("Your matches will appear here after uploading a names file and running a match.")

# Footer
st.markdown("---")
st.markdown("")