# Khmer Name OCR Matcher

A Python module for matching and correcting Khmer names from OCR text, supporting both Khmer script and Latin transliteration. This library provides robust name matching capabilities using multiple algorithms and statistical frequency data.

## Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Basic Usage](#basic-usage)
- [Detailed Usage Guide](#detailed-usage-guide)
  - [Initializing the Matcher](#initializing-the-matcher)
  - [Loading Name Data](#loading-name-data)
  - [Individual Matching Methods](#individual-matching-methods)
  - [Hybrid Matching](#hybrid-matching)
  - [Latin Name Matching](#latin-name-matching)
  - [Batch Processing](#batch-processing)
  - [Customizing Weights](#customizing-weights)
  - [Frequency Boosting](#frequency-boosting)
  - [Exporting Results](#exporting-results)
- [Data Format](#data-format)
- [Performance Optimization](#performance-optimization)
  - [Index Saving and Loading](#index-saving-and-loading)
  - [GPU Acceleration](#gpu-acceleration)
  - [Batch Processing](#batch-processing-1)
  - [Model Selection](#model-selection)
- [Command-line Interface](#command-line-interface)
- [API Reference](#api-reference)
- [Example Scripts](#example-scripts)
- [Troubleshooting](#troubleshooting)
- [License](#license)
- [Acknowledgements](#acknowledgements)

## Features

- **Multi-strategy name matching**:
  - **Semantic matching**: Uses multilingual embeddings to find names with similar meanings
  - **TF-IDF matching**: Uses character n-grams to find names with similar character patterns
  - **Character-based similarity**: Uses Jaccard index for direct character comparison
  - **Hybrid matching**: Combines all methods with configurable weights
- **Dual-script support**: Match names in both Khmer script and Latin transliteration
- **Frequency-based boosting**: Prioritizes common names based on statistical frequency
- **Batch processing**: Process multiple names at once for efficiency
- **Flexible input**: Load names from files or directly from Python lists
- **Hardware acceleration**: Supports both CPU and GPU (CUDA) for fast processing
- **Detailed scoring**: Access individual and combined scores for transparency
- **Index saving/loading**: Save and load pre-built indexes for faster startup

## Installation

### Requirements

- Python 3.7+
- PyTorch
- sentence-transformers
- faiss-cpu or faiss-gpu
- numpy
- scikit-learn
- fuzzywuzzy
- pandas (for reporting)

### Quick Install

```bash
# Basic installation (CPU only)
pip install torch sentence-transformers faiss-cpu numpy scikit-learn fuzzywuzzy pandas python-Levenshtein

# For GPU support (if you have a compatible NVIDIA GPU)
pip install torch sentence-transformers faiss-gpu numpy scikit-learn fuzzywuzzy pandas python-Levenshtein
```

### From Requirements File

```bash
pip install -r requirements.txt
```

## Basic Usage

Here's a simple example to get started:

```python
from khmer_matcher import KhmerNameMatcher

# Initialize with a file containing names
matcher = KhmerNameMatcher("khmer_names.txt")

# Simple name matching
results = matcher.hybrid_match("ប៉ាន់ វឌ្ឍនៈ")
for name, score in results:
    print(f"{name}: {score:.3f}")

# Match with Latin/English name
results = matcher.match_with_latin_fallback(
    "ប៉ាន់ វឌ្ឍនៈ",   # Khmer name
    "Pan Vathana"      # Latin/English name
)

for khmer, khmer_score, latin, combined, latin_score, freq in results:
    print(f"{khmer} ({latin}): {combined:.3f}")
```

## Detailed Usage Guide

### Initializing the Matcher

The `KhmerNameMatcher` class is the main entry point. You can initialize it in several ways:

```python
# With a names file and auto-detected device (GPU if available, CPU otherwise)
matcher = KhmerNameMatcher("khmer_names.txt")

# Explicitly specifying the device
matcher = KhmerNameMatcher("khmer_names.txt", device="cpu")
matcher = KhmerNameMatcher("khmer_names.txt", device="cuda")

# Specifying a different sentence-transformer model
matcher = KhmerNameMatcher(
    "khmer_names.txt", 
    model_name="distiluse-base-multilingual-cased-v1"
)

# Initialize empty and load data later
matcher = KhmerNameMatcher()
matcher.load_names("khmer_names.txt")

# With index saving/loading for better performance
matcher = KhmerNameMatcher("khmer_names.txt", index_dir="indexes")
```

### Loading Name Data

You can load name data from a file or directly from Python lists:

```python
# Load from file
matcher.load_names("khmer_names.txt")

# Load from Python lists
khmer_names = ["ប៉ាន់ វឌ្ឍនៈ", "ហ៊ុន សែន", "សិន សុីសាមុត"]
latin_names = ["Pan Vathana", "Hun Sen", "Sinn Sisamouth"]
matcher.load_names_from_list(khmer_names, latin_names)

# Check if Latin names are available
has_latin = matcher.has_latin_names()

# Get Latin name for a Khmer name
latin = matcher.get_latin_name("ហ៊ុន សែន")  # Returns "Hun Sen" if available

# Get frequency of a name
freq = matcher.get_name_frequency("ហ៊ុន សែន")
```

### Individual Matching Methods

The library provides several matching methods with different strengths:

#### 1. Semantic Matching

Uses multilingual sentence embeddings to find semantically similar names:

```python
# Get top 5 semantically similar names
results = matcher.match_name("ប៉ាន់ វឌ្ឍនៈ", top_k=5)
for name, score in results:
    print(f"{name}: {score:.3f}")
```

#### 2. TF-IDF Matching

Uses character n-grams with TF-IDF weighting to find names with similar character patterns:

```python
# Get top 5 TF-IDF matches
results = matcher.tfidf_search("ប៉ាន់ វឌ្ឍនៈ", top_k=5)
for name, score in results:
    print(f"{name}: {score:.3f}")
```

#### 3. Keyword Matching

Uses Jaccard similarity (character overlap) to find names with similar characters:

```python
# Get top 5 keyword matches
results = matcher.keyword_search("ប៉ាន់ វឌ្ឍនៈ", top_k=5)
for name, score in results:
    print(f"{name}: {score:.3f}")
```

### Hybrid Matching

Combines all three methods (semantic, TF-IDF, and keyword) with configurable weights:

```python
# Default weights: semantic=0.6, tfidf=0.2, keyword=0.2
results = matcher.hybrid_match("ប៉ាន់ វឌ្ឍនៈ", top_k=5)

# Custom weights
results = matcher.hybrid_match(
    "ប៉ាន់ វឌ្ឍនៈ", 
    top_k=5,
    semantic_weight=0.5,   # 50% weight to semantic matching
    tfidf_weight=0.3       # 30% weight to TF-IDF, remaining 20% to keyword
)

# Access results with frequency information
for name, score in results:
    freq = matcher.get_name_frequency(name)
    latin = matcher.get_latin_name(name)
    print(f"{name} ({latin}): Score={score:.3f}, Frequency={freq}")
```

### Latin Name Matching

For bilingual matching, use both Khmer and Latin/English names:

```python
# Match with both Khmer and Latin names
results = matcher.match_with_latin_fallback(
    "ប៉ាន់ វឌ្ឍនៈ",   # Khmer name
    "Pan Vathana",     # Latin/English name
    top_k=5,
    semantic_weight=0.6,  # Weight for semantic matching
    tfidf_weight=0.2,     # Weight for TF-IDF matching
    latin_weight=0.5      # Weight for Latin name matching vs Khmer matching
)

# Detailed results with all scores
for khmer, khmer_score, latin, combined, latin_score, freq in results:
    print(f"Match: {khmer} ({latin})")
    print(f"  Khmer score: {khmer_score:.3f}, Latin score: {latin_score:.3f}")
    print(f"  Combined score: {combined:.3f}, Frequency: {freq}")
```

### Batch Processing

Process multiple names at once for efficiency:

```python
# Prepare lists of names
khmer_queries = [
    "ឡាយ សុគន្ធ",
    "សិន សុីសាមុត", 
    "ហ៊ុន សែន"
]
latin_queries = [
    "Lay Sokun",
    "Sinn Sisamouth",
    "Hun Sen"
]

# Process all names at once
batch_results = matcher.match_batch(
    khmer_queries, 
    latin_queries,
    top_k=5,
    semantic_weight=0.6,
    tfidf_weight=0.2,
    latin_weight=0.5
)

# Access results for each query
for query, matches in batch_results.items():
    print(f"\nMatches for '{query}':")
    for name, khmer_score, latin, combined_score, latin_score, freq in matches:
        print(f"  - {name} ({latin}): {combined_score:.3f}")
```

### Customizing Weights

Fine-tune the matching by adjusting weights:

```python
# For character-heavy matching (useful for badly OCR'd text)
results = matcher.hybrid_match(
    "ប៉ាន់ វឌ្ឍនៈ",
    semantic_weight=0.3,  # Less weight on semantic
    tfidf_weight=0.4      # More weight on character patterns
)

# For semantic-heavy matching (useful for well-formed text)
results = matcher.hybrid_match(
    "ប៉ាន់ វឌ្ឍនៈ",
    semantic_weight=0.8,  # High weight on semantic
    tfidf_weight=0.1      # Low weight on character patterns
)

# For balanced Latin-Khmer matching
results = matcher.match_with_latin_fallback(
    "ប៉ាន់ វឌ្ឍនៈ",
    "Pan Vathana",
    latin_weight=0.5      # Equal weight to Khmer and Latin
)

# For Khmer-dominant matching with Latin refinement
results = matcher.match_with_latin_fallback(
    "ប៉ាន់ វឌ្ឍនៈ",
    "Pan Vathana",
    latin_weight=0.3      # 70% Khmer, 30% Latin
)
```

### Frequency Boosting

The matcher automatically applies frequency boosting based on how many times a name appears in your dataset:

```python
# The frequency boost is applied automatically in hybrid_match and match_with_latin_fallback
# The boost formula is: 1.0 + (0.1 * log(1 + frequency))

# To get the raw frequency of a name:
frequency = matcher.get_name_frequency("ហ៊ុន សែន")
print(f"Name appears {frequency} times in the dataset")

# This means a name that appears 10 times gets a ~1.23x boost
# A name that appears 100 times gets a ~1.46x boost
# This helps prioritize common names without overwhelming other matching factors
```

### Exporting Results

You can export matching results to CSV for further analysis:

```python
import pandas as pd

# Process a batch of names
batch_results = matcher.match_batch(khmer_queries, latin_queries)

# Prepare data for export
all_results = []
for query, matches in batch_results.items():
    for match in matches:
        khmer_name, khmer_score, latin_name, combined_score, latin_score, freq = match
        all_results.append({
            "query": query,
            "match_khmer": khmer_name,
            "match_latin": latin_name,
            "khmer_score": khmer_score,
            "latin_score": latin_score,
            "combined_score": combined_score,
            "frequency": freq
        })

# Create and save DataFrame
df = pd.DataFrame(all_results)
df.to_csv("matching_results.csv", index=False, encoding="utf-8")
```

## Data Format

### Input File Format

The name file should contain one name per line, with optional Latin transliterations:

```
ប៉ាន់ វឌ្ឍនៈ,Pan Vathana
ហ៊ុន សែន,Hun Sen
សិន សុីសាមុត,Sinn Sisamouth
```

For Khmer-only names without Latin transliterations:

```
ប៉ាន់ វឌ្ឍនៈ
ហ៊ុន សែន
សិន សុីសាមុត
```

### Handling Duplicates

Duplicates in the input file are intentionally counted for frequency statistics:

```
ហ៊ុន សែន,Hun Sen
ហ៊ុន សែន,Hun Sen
ហ៊ុន សែន,Hun Sen
```

This indicates that "ហ៊ុន សែន" appears 3 times, giving it a higher frequency boost.

## Performance Optimization

### Index Saving and Loading

For better performance, you can save and load pre-built indexes:

```python
# Initialize with index directory
matcher = KhmerNameMatcher(
    "khmer_names.txt", 
    index_dir="indexes"
)

# The matcher will:
# 1. Try to load existing indexes from the directory
# 2. If not found, build indexes from scratch and save them
# 3. On next run, load the saved indexes (much faster)

# This saves:
# - FAISS index for semantic search
# - TF-IDF vectorizer and matrix
# - Name metadata (frequencies, latin mappings)
# - Pre-computed embeddings
```

You can also use the command line to save indexes:

```bash
# Save indexes after loading
python -m khmer_matcher --names khmer_names.txt --index-dir indexes --save-index --khmer "ប៉ាន់ វឌ្ឍនៈ"
```

For large datasets, this can reduce startup time from minutes to seconds.

### GPU Acceleration

For faster processing, use a CUDA-capable GPU:

```python
# GPU is auto-detected and used if available
matcher = KhmerNameMatcher("khmer_names.txt")

# Force GPU usage
matcher = KhmerNameMatcher("khmer_names.txt", device="cuda")

# Force CPU usage (if running into GPU memory issues)
matcher = KhmerNameMatcher("khmer_names.txt", device="cpu")
```

### Batch Processing

Always use batch processing for multiple names:

```python
# Inefficient (repeated model inference)
results1 = matcher.hybrid_match("ប៉ាន់ វឌ្ឍនៈ")
results2 = matcher.hybrid_match("ហ៊ុន សែន")
results3 = matcher.hybrid_match("សិន សុីសាមុត")

# Efficient (single batch processing)
batch_results = matcher.match_batch([
    "ប៉ាន់ វឌ្ឍនៈ", 
    "ហ៊ុន សែន", 
    "សិន សុីសាមុត"
])
```

### Model Selection

Different sentence-transformer models offer different speed/accuracy tradeoffs:

```python
# Default model (best quality, slower)
matcher = KhmerNameMatcher(
    "khmer_names.txt", 
    model_name="paraphrase-multilingual-mpnet-base-v2"
)

# Smaller model (faster, still good quality)
matcher = KhmerNameMatcher(
    "khmer_names.txt", 
    model_name="distiluse-base-multilingual-cased-v1"
)
```

## Command-line Interface

The module includes a simple command-line interface:

```bash
# Basic usage
python -m khmer_matcher --names khmer_names.txt --khmer "ប៉ាន់ វឌ្ឍនៈ"

# With Latin/English name
python -m khmer_matcher --names khmer_names.txt --khmer "ប៉ាន់ វឌ្ឍនៈ" --latin "Pan Vathana"

# With custom weights
python -m khmer_matcher --names khmer_names.txt --khmer "ប៉ាន់ វឌ្ឍនៈ" --latin "Pan Vathana" \
    --top-k 5 --semantic-weight 0.6 --tfidf-weight 0.2 --latin-weight 0.5

# With index saving/loading
python -m khmer_matcher --names khmer_names.txt --khmer "ប៉ាន់ វឌ្ឍនៈ" --index-dir indexes

# Save indexes for future use
python -m khmer_matcher --names khmer_names.txt --index-dir indexes --save-index --khmer "ប៉ាន់ វឌ្ឍនៈ"
```

## API Reference

### `KhmerNameMatcher` Class

**Constructor**:
```python
KhmerNameMatcher(names_file=None, model_name="paraphrase-multilingual-mpnet-base-v2", device=None, index_dir=None)
```

**Main Methods**:
- `load_names(filename)`: Load names from a file
- `load_names_from_list(khmer_names, latin_names=None)`: Load names from Python lists
- `match_name(query, top_k=5)`: Semantic matching
- `tfidf_search(query, top_k=5)`: TF-IDF character n-gram matching
- `keyword_search(query, top_k=5)`: Character Jaccard similarity matching
- `hybrid_match(query, top_k=5, semantic_weight=0.6, tfidf_weight=0.2)`: Combined matching
- `match_with_latin_fallback(khmer_query, latin_query, top_k=5, semantic_weight=0.6, tfidf_weight=0.2, latin_weight=0.5)`: Two-stage matching with Latin
- `match_batch(khmer_queries, latin_queries=None, top_k=5, semantic_weight=0.6, tfidf_weight=0.2, latin_weight=0.5)`: Batch processing

**Utility Methods**:
- `has_latin_names()`: Check if Latin mappings exist
- `get_latin_name(khmer_name)`: Get Latin transliteration
- `get_name_frequency(name)`: Get frequency count
- `calculate_latin_score(query, target)`: Calculate similarity between Latin strings
- `_save_indexes(names_file)`: Save indexes to disk
- `_load_indexes(names_file)`: Load indexes from disk

## Example Scripts

See the included `example.py` for a complete demonstration of the library's capabilities:

```bash
python example.py
```

The example script demonstrates:
1. Loading names from a file
2. Using different matching methods
3. Customizing weights
4. Batch processing
5. Exporting results to CSV

## Troubleshooting

### Common Issues

**GPU Out of Memory**:
```python
# Use CPU instead
matcher = KhmerNameMatcher("khmer_names.txt", device="cpu")
```

**Missing Latin Mappings**:
```python
# Check if Latin names are available
if matcher.has_latin_names():
    # Use Latin matching
else:
    # Fall back to Khmer-only matching
```

**Unbalanced Weights**:
```python
# The library automatically normalizes weights if they sum to > 1.0
# But it's better to ensure they sum to 1.0 manually
semantic_weight = 0.6
tfidf_weight = 0.2
keyword_weight = 1.0 - semantic_weight - tfidf_weight  # = 0.2
```

**Slow Initialization**:
```python
# Use index saving/loading for faster startup
matcher = KhmerNameMatcher("khmer_names.txt", index_dir="indexes")

# First run will be slow as it builds and saves indexes
# Subsequent runs will be much faster
```

## License

MIT

## Acknowledgements

- Uses [sentence-transformers](https://github.com/UKPLab/sentence-transformers) for multilingual embeddings
- Uses [FAISS](https://github.com/facebookresearch/faiss) for efficient similarity search
- Uses [FuzzyWuzzy](https://github.com/seatgeek/fuzzywuzzy) for string similarity
- Uses [scikit-learn](https://scikit-learn.org/) for TF-IDF vectorization 