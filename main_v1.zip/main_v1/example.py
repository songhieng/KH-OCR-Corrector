#!/usr/bin/env python
"""
Example usage of KhmerNameMatcher module.
This demonstrates how to use the module for Khmer name matching.
"""

from khmer_matcher import KhmerNameMatcher
import pandas as pd

def main():
    print("Khmer Name Matcher Example")
    print("=========================")
    
    # Initialize the matcher with a names file
    # Use CPU if no GPU is available
    matcher = KhmerNameMatcher("khmer_names.txt", device="cpu")
    
    # Simple matching example
    khmer_query = "ប៉ាន់ វឌ្ឍនៈ"
    print(f"\nMatching Khmer name: '{khmer_query}'")
    
    # Try different matching methods
    print("\n1. Semantic matching:")
    semantic_matches = matcher.match_name(khmer_query)
    for name, score in semantic_matches:
        print(f"  - {name}: {score:.3f}")
    
    print("\n2. TF-IDF matching:")
    tfidf_matches = matcher.tfidf_search(khmer_query)
    for name, score in tfidf_matches:
        print(f"  - {name}: {score:.3f}")
    
    print("\n3. Keyword matching:")
    keyword_matches = matcher.keyword_search(khmer_query)
    for name, score in keyword_matches:
        print(f"  - {name}: {score:.3f}")
    
    print("\n4. Hybrid matching:")
    hybrid_matches = matcher.hybrid_match(khmer_query)
    for name, score in hybrid_matches:
        latin = matcher.get_latin_name(name)
        freq = matcher.get_name_frequency(name)
        print(f"  - {name}" + (f" ({latin})" if latin else ""))
        print(f"    Score: {score:.3f}, Frequency: {freq}")
    
    # Latin + Khmer matching
    latin_query = "Pan Vathana"
    print(f"\n5. Khmer + Latin matching:")
    print(f"   Khmer: '{khmer_query}', Latin: '{latin_query}'")
    latin_matches = matcher.match_with_latin_fallback(khmer_query, latin_query)
    for khmer, khmer_score, latin, combined, latin_score, freq in latin_matches:
        print(f"  - {khmer}" + (f" ({latin})" if latin else ""))
        print(f"    Khmer: {khmer_score:.3f}, Latin: {latin_score:.3f}")
        print(f"    Combined: {combined:.3f}, Frequency: {freq}")
    
    # Batch processing example
    print("\n6. Batch processing:")
    khmer_queries = [
        "ឡាយ សុគន្ធ",
        "សិន សុីសាមុត", 
        "ហ៊ុន សែន"
    ]
    latin_queries = [
        "Lay Sokun",
        "Sinn Sisamouth",
        "Hun Sen"
    ]
    
    batch_results = matcher.match_batch(khmer_queries, latin_queries)
    
    for query, results in batch_results.items():
        print(f"\nMatches for '{query}':")
        for name, khmer_score, latin, combined_score, latin_score, freq in results[:3]:  # Show top 3
            print(f"  - {name}" + (f" ({latin})" if latin else ""))
            print(f"    Score: {combined_score:.3f}, Frequency: {freq}")
    
    # Create a simple report
    print("\n7. Saving sample report to 'matches.csv'")
    
    # Get data for report
    all_results = []
    for i, query in enumerate(khmer_queries):
        latin = latin_queries[i] if i < len(latin_queries) else ""
        matches = matcher.match_with_latin_fallback(query, latin, top_k=3)
        
        for match in matches:
            khmer_name, khmer_score, latin_name, combined_score, latin_score, freq = match
            all_results.append({
                "query_khmer": query,
                "query_latin": latin,
                "match_khmer": khmer_name,
                "match_latin": latin_name,
                "khmer_score": khmer_score,
                "latin_score": latin_score,
                "combined_score": combined_score,
                "frequency": freq
            })
    
    # Create and save DataFrame
    df = pd.DataFrame(all_results)
    df.to_csv("matches.csv", index=False, encoding="utf-8")
    print("Report saved!")

if __name__ == "__main__":
    main() 