import numpy as np
import faiss
import torch
from sentence_transformers import SentenceTransformer
from difflib import SequenceMatcher
from typing import List, Tuple, Dict, Counter as CounterType, Optional
from fuzzywuzzy import fuzz
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
import logging
import re
import os
import pickle
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("KhmerNameMatcher")

class KhmerNameMatcher:
    """
    A class for matching Khmer names using a combination of semantic, TF-IDF, and character-based
    approaches, with optional Latin transliteration support.
    """
    
    def __init__(self, names_file: str = None, model_name: str = "paraphrase-multilingual-mpnet-base-v2", 
                 device: str = None, index_dir: str = None):
        """
        Initialize the KhmerNameMatcher.
        
        Args:
            names_file: Path to a file containing Khmer names, optionally with Latin transliterations
            model_name: Name of the SentenceTransformer model to use
            device: Device to use for model inference ('cuda', 'cpu', or None for auto-detection)
            index_dir: Directory to load/save index files (if None, indexes won't be saved)
        """
        # Auto-detect device if not specified
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        
        self.device = device
        self.model_name = model_name
        self.index_dir = index_dir
        
        logger.info(f"Using device: {self.device}")
        logger.info(f"Using model: {self.model_name}")
        
        self.model = SentenceTransformer(model_name, device=self.device)
        
        # Initialize empty data structures
        self.names = []
        self.latin_map = {}
        self.name_counts = Counter()
        self.index = None
        self.tfidf = None
        self.tfidf_matrix = None
        self.embeddings = None
        
        if names_file:
            # Try to load from saved index first
            if index_dir and self._load_indexes(names_file):
                logger.info(f"Loaded indexes from {index_dir}")
            else:
                # Otherwise load from raw file
                self.load_names(names_file)
                # Save indexes if directory is specified
                if index_dir:
                    self._save_indexes(names_file)

    def _get_index_paths(self, names_file):
        """Get paths for all index files based on names_file and model name"""
        if not self.index_dir:
            return None
            
        # Create directory if it doesn't exist
        os.makedirs(self.index_dir, exist_ok=True)
        
        # Create a base filename from the names file and model
        base_name = os.path.splitext(os.path.basename(names_file))[0]
        model_suffix = self.model_name.replace("-", "_").replace("/", "_")
        
        # Define paths for each component
        faiss_path = os.path.join(self.index_dir, f"{base_name}_{model_suffix}.faiss")
        meta_path = os.path.join(self.index_dir, f"{base_name}_{model_suffix}.meta")
        tfidf_path = os.path.join(self.index_dir, f"{base_name}_{model_suffix}.tfidf")
        emb_path = os.path.join(self.index_dir, f"{base_name}_{model_suffix}.npy")
        
        return {
            "faiss": faiss_path,
            "meta": meta_path,
            "tfidf": tfidf_path,
            "embeddings": emb_path
        }

    def _save_indexes(self, names_file):
        """Save indexes and metadata to files"""
        if not self.index_dir:
            return False
            
        paths = self._get_index_paths(names_file)
        if not paths:
            return False
            
        try:
            # Save FAISS index
            if self.index:
                faiss.write_index(self.index, paths["faiss"])
                logger.info(f"Saved FAISS index to {paths['faiss']}")
            
            # Save metadata (names, latin_map, name_counts)
            metadata = {
                "names": self.names,
                "latin_map": self.latin_map,
                "name_counts": dict(self.name_counts)
            }
            with open(paths["meta"], 'wb') as f:
                pickle.dump(metadata, f)
            logger.info(f"Saved metadata to {paths['meta']}")
            
            # Save TF-IDF vectorizer and matrix
            if self.tfidf and self.tfidf_matrix is not None:
                tfidf_data = {
                    "vectorizer": self.tfidf,
                    "matrix": self.tfidf_matrix
                }
                with open(paths["tfidf"], 'wb') as f:
                    pickle.dump(tfidf_data, f)
                logger.info(f"Saved TF-IDF data to {paths['tfidf']}")
            
            # Save embeddings for future use
            if self.embeddings is not None:
                np.save(paths["embeddings"], self.embeddings)
                logger.info(f"Saved embeddings to {paths['embeddings']}")
                
            return True
            
        except Exception as e:
            logger.error(f"Error saving indexes: {str(e)}")
            return False

    def _load_indexes(self, names_file):
        """Load indexes and metadata from files"""
        if not self.index_dir:
            return False
            
        paths = self._get_index_paths(names_file)
        if not paths:
            return False
            
        # Check if all necessary files exist
        if not (os.path.exists(paths["faiss"]) and 
                os.path.exists(paths["meta"]) and 
                os.path.exists(paths["tfidf"])):
            logger.info(f"Index files not found for {names_file}")
            return False
            
        try:
            # Load FAISS index
            self.index = faiss.read_index(paths["faiss"])
            logger.info(f"Loaded FAISS index from {paths['faiss']}")
            
            # Load metadata
            with open(paths["meta"], 'rb') as f:
                metadata = pickle.load(f)
                self.names = metadata["names"]
                self.latin_map = metadata["latin_map"]
                self.name_counts = Counter(metadata["name_counts"])
            logger.info(f"Loaded metadata from {paths['meta']}")
            
            # Load TF-IDF data
            with open(paths["tfidf"], 'rb') as f:
                tfidf_data = pickle.load(f)
                self.tfidf = tfidf_data["vectorizer"]
                self.tfidf_matrix = tfidf_data["matrix"]
            logger.info(f"Loaded TF-IDF data from {paths['tfidf']}")
            
            # Load embeddings if available
            if os.path.exists(paths["embeddings"]):
                self.embeddings = np.load(paths["embeddings"])
                logger.info(f"Loaded embeddings from {paths['embeddings']}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error loading indexes: {str(e)}")
            # Reset to empty state if loading fails
            self.names = []
            self.latin_map = {}
            self.name_counts = Counter()
            self.index = None
            self.tfidf = None
            self.tfidf_matrix = None
            self.embeddings = None
            return False

    def load_names(self, filename: str) -> Tuple[List[str], Dict[str, str], CounterType[str]]:
        """
        Load names from a file.
        
        The file should contain one name per line, optionally with Latin transliterations
        in the format: "KhmerName,LatinName"
        
        Args:
            filename: Path to the file containing names
            
        Returns:
            Tuple of (unique names list, Latin mapping dict, name frequency counter)
        """
        raw_names: List[str] = []
        latin_map: Dict[str, str] = {}
        
        logger.info(f"Loading names from: {filename}")
        
        with open(filename, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                
                # Expecting "Khmer,Latin"
                parts = line.split(',', 1)
                if len(parts) >= 2:
                    khmer = parts[0].strip()
                    latin = parts[1].strip().rstrip(',')
                    
                    if khmer and latin:
                        raw_names.append(khmer)
                        latin_map[khmer] = latin
                        
                        # Debug first few entries
                        if line_num <= 5:
                            logger.debug(f"Line {line_num}: Mapped Khmer '{khmer}' -> Latin '{latin}'")
                else:
                    # No comma or only one part: treat as Khmer-only
                    khmer_only = parts[0].strip()
                    raw_names.append(khmer_only)
                    
                    # Debug first few entries
                    if line_num <= 5:
                        logger.debug(f"Line {line_num}: Added Khmer-only '{khmer_only}'")
        
        # Count frequencies (keeping duplicates for statistics)
        name_counts = Counter(raw_names)
        unique_names = list(name_counts.keys())
        
        logger.info(f"Loaded {len(raw_names)} Khmer names ({len(unique_names)} unique) and {len(latin_map)} Latin mappings")
        if len(name_counts) > 0:
            logger.info(f"Top 5 most frequent names: {name_counts.most_common(5)}")
        
        self.names = unique_names
        self.latin_map = latin_map
        self.name_counts = name_counts
        
        # Build indexes
        self._build_index()
        self._build_tfidf()
        
        return self.names, self.latin_map, self.name_counts

    def load_names_from_list(self, khmer_names: List[str], latin_names: List[str] = None) -> None:
        """
        Load names from Python lists.
        
        Args:
            khmer_names: List of Khmer names
            latin_names: Optional list of Latin transliterations (must be same length as khmer_names)
        """
        if latin_names and len(khmer_names) != len(latin_names):
            raise ValueError(f"Length mismatch: {len(khmer_names)} Khmer names vs {len(latin_names)} Latin names")
            
        raw_names = khmer_names
        latin_map = {}
        
        if latin_names:
            for khmer, latin in zip(khmer_names, latin_names):
                if khmer and latin:
                    latin_map[khmer] = latin
        
        # Count frequencies
        name_counts = Counter(raw_names)
        unique_names = list(name_counts.keys())
        
        logger.info(f"Loaded {len(raw_names)} Khmer names ({len(unique_names)} unique) and {len(latin_map)} Latin mappings")
        
        self.names = unique_names
        self.latin_map = latin_map
        self.name_counts = name_counts
        
        # Build indexes
        self._build_index()
        self._build_tfidf()
        
        return self.names, self.latin_map, self.name_counts

    def _build_index(self):
        """Build FAISS index for semantic search"""
        if not self.names:
            logger.warning("No names to index")
            return
            
        logger.info("Building FAISS index for semantic search...")
        
        # Move computation to device (GPU or CPU)
        embeddings = self.model.encode(
            self.names,
            convert_to_tensor=True,
            device=self.device,
            show_progress_bar=True
        )

        # Move to CPU for FAISS (if on GPU)
        emb_np = embeddings.detach().cpu().numpy()
        
        # Save embeddings for future use
        self.embeddings = emb_np.copy()

        # Normalize for cosine similarity
        faiss.normalize_L2(emb_np)
        
        # Create and populate FAISS index
        dim = emb_np.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(emb_np)
        logger.info(f"FAISS index built with {len(self.names)} vectors of dimension {dim}")
    
    def _build_tfidf(self):
        """Build TF-IDF vectors for character n-grams in names"""
        if not self.names:
            logger.warning("No names to build TF-IDF vectors")
            return
            
        logger.info("Building TF-IDF vectors for character n-grams...")
        
        # Tokenize names into character n-grams
        def char_ngrams(text, n_range=(1, 3)):
            text = text.lower()
            tokens = []
            for n in range(n_range[0], n_range[1] + 1):
                for i in range(len(text) - n + 1):
                    tokens.append(text[i:i+n])
            return " ".join(tokens)
        
        # Prepare corpus with character n-grams
        corpus = [char_ngrams(name) for name in self.names]
        
        # Build TF-IDF vectorizer
        self.tfidf = TfidfVectorizer(analyzer='word', ngram_range=(1, 1))
        self.tfidf_matrix = self.tfidf.fit_transform(corpus)
        
        logger.info(f"Built TF-IDF matrix with shape: {self.tfidf_matrix.shape}")

    def match_name(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:
        """
        Perform semantic matching of a query against the name database.
        
        Args:
            query: The name to match
            top_k: Number of results to return
            
        Returns:
            List of (name, score) tuples
        """
        q = query.strip()
        if not q:
            return []
        if not self.index:
            logger.error("No index built. Load names first.")
            return []

        # GPU encoding
        emb = self.model.encode(
            [q],
            convert_to_tensor=True,
            device=self.device
        )

        # Convert to NumPy for FAISS (FAISS is on CPU)
        emb_np = emb.detach().cpu().numpy()
        faiss.normalize_L2(emb_np)

        # FAISS search
        scores, idxs = self.index.search(emb_np, min(top_k, len(self.names)))
        return [(self.names[i], float(scores[0][j])) for j, i in enumerate(idxs[0])]

    def keyword_search(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:
        """
        Perform character-based matching using Jaccard similarity.
        
        Args:
            query: The name to match
            top_k: Number of results to return
            
        Returns:
            List of (name, score) tuples
        """
        if not query or not self.names: 
            return []
            
        scores = []
        qset = set(query)
        for name in self.names:
            nset = set(name)
            overlap = len(qset & nset)
            union = len(qset | nset) or 1
            scores.append((name, overlap/union))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]
    
    def tfidf_search(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:
        """
        Search using TF-IDF character n-grams.
        
        Args:
            query: The name to match
            top_k: Number of results to return
            
        Returns:
            List of (name, score) tuples
        """
        if not query or not self.tfidf: 
            return []
        
        # Tokenize query into character n-grams
        def char_ngrams(text, n_range=(1, 3)):
            text = text.lower()
            tokens = []
            for n in range(n_range[0], n_range[1] + 1):
                for i in range(len(text) - n + 1):
                    tokens.append(text[i:i+n])
            return " ".join(tokens)
        
        # Transform query to TF-IDF space
        query_ngrams = char_ngrams(query)
        query_tfidf = self.tfidf.transform([query_ngrams])
        
        # Calculate cosine similarity with all names
        similarities = (query_tfidf @ self.tfidf_matrix.T).toarray()[0]
        
        # Get top-k names
        results = [(self.names[i], float(similarities[i])) 
                   for i in np.argsort(similarities)[::-1][:top_k]]
        
        return results

    def hybrid_match(self, query: str, top_k: int = 5, semantic_weight: float = 0.6, 
                    tfidf_weight: float = 0.2) -> List[Tuple[str, float]]:
        """
        Combine semantic, TF-IDF, and keyword matching with frequency boosting.
        
        Args:
            query: The name to match
            top_k: Number of results to return
            semantic_weight: Weight for semantic matching (0.0-1.0)
            tfidf_weight: Weight for TF-IDF matching (0.0-1.0)
            
        Returns:
            List of (name, score) tuples
        """
        if not query or not self.names:
            return []
            
        # Ensure weights sum to 1.0
        if semantic_weight + tfidf_weight > 1.0:
            logger.warning(f"Weights sum > 1.0, normalizing")
            total = semantic_weight + tfidf_weight
            semantic_weight /= total
            tfidf_weight /= total
            
        keyword_weight = 1.0 - semantic_weight - tfidf_weight
        
        sem = dict(self.match_name(query, top_k*2))
        kw = dict(self.keyword_search(query, top_k*2))
        tfidf = dict(self.tfidf_search(query, top_k*2))
        
        # Combine scores
        combined = {}
        for name_list, weight in [(sem, semantic_weight), 
                                 (tfidf, tfidf_weight), 
                                 (kw, keyword_weight)]:
            for name, score in name_list.items():
                if name not in combined:
                    combined[name] = 0
                combined[name] += score * weight
        
        # Apply frequency boost (logarithmic to avoid overpowering)
        for name in combined:
            freq = self.name_counts.get(name, 1)
            freq_boost = 1.0 + (0.1 * np.log1p(freq))  # Logarithmic boost
            combined[name] *= freq_boost
        
        return sorted(combined.items(), key=lambda x: x[1], reverse=True)[:top_k]
                
    def has_latin_names(self) -> bool:
        """Check if the loaded dataset has Latin name mappings"""
        return len(self.latin_map) > 0
    
    def get_latin_name(self, khmer_name: str) -> str:
        """Get the Latin transliteration for a Khmer name if available"""
        return self.latin_map.get(khmer_name, "")
    
    def get_name_frequency(self, name: str) -> int:
        """Get frequency count for a name"""
        return self.name_counts.get(name, 0)
    
    def calculate_latin_score(self, query: str, target: str) -> float:
        """
        Calculate similarity score between two Latin strings.
        
        Args:
            query: Query string
            target: Target string
            
        Returns:
            Similarity score (0.0-1.0)
        """
        if not query or not target:
            return 0.0
            
        q = query.lower().strip()
        t = target.lower().strip()
        
        # Exact match shortcut
        if q == t:
            return 1.0
            
        # SequenceMatcher blocks
        sm = SequenceMatcher(None, q, t)
        matched_chars = sum(block.size for block in sm.get_matching_blocks())
        max_len = max(len(q), len(t))
        latin_score = matched_chars / max_len
        
        # FuzzyWuzzy for comparison
        fuzzy = fuzz.ratio(q, t)
        fuzzy_norm = fuzzy / 100.0
        
        # Take the higher of the two scores
        return max(latin_score, fuzzy_norm)
    
    def match_with_latin_fallback(
        self,
        khmer_query: str,
        latin_query: str,
        top_k: int = 5,
        semantic_weight: float = 0.6,
        tfidf_weight: float = 0.2,
        latin_weight: float = 0.5
    ) -> List[Tuple[str, float, str, float, float, int]]:
        """
        Two-stage matching: first semantic+tfidf+keyword match on Khmer, then refine with Latin matching.
        
        Args:
            khmer_query: Khmer name to match
            latin_query: Latin/English name to match
            top_k: Number of results to return
            semantic_weight: Weight for semantic matching (0.0-1.0)
            tfidf_weight: Weight for TF-IDF matching (0.0-1.0)
            latin_weight: Weight for Latin matching vs Khmer matching (0.0-1.0)
            
        Returns:
            List of tuples: (khmer_name, semantic_score, latin_name, combined_score, latin_score, frequency)
        """
        if not khmer_query or not self.names:
            return []
            
        # 1) Semantic + TF-IDF + keyword on Khmer
        khmer_matches = self.hybrid_match(khmer_query, top_k * 10, semantic_weight, tfidf_weight)

        # 2) If no Latin data or no Latin query, skip second stage
        if not latin_query or not self.has_latin_names():
            return [
                (name, score, self.get_latin_name(name), score, 0.0, self.get_name_frequency(name))
                for name, score in khmer_matches[:top_k]
            ]

        # 3) Refine each Khmer candidate by comparing Latin strings
        refined = []
        q = latin_query.lower().strip()
        for khmer_name, khmer_score in khmer_matches:
            latin_name = self.get_latin_name(khmer_name) or ""
            frequency = self.get_name_frequency(khmer_name)
            latin_score = 0.0

            if latin_name:
                latin_score = self.calculate_latin_score(q, latin_name)
                
                # Combine Khmer & Latin with latin_weight
                combined = khmer_score * (1 - latin_weight) + latin_score * latin_weight
                
                # Apply frequency boost
                freq_boost = 1.0 + (0.1 * np.log1p(frequency))
                combined *= freq_boost
            else:
                combined = khmer_score

            refined.append((khmer_name, khmer_score, latin_name, combined, latin_score, frequency))

        # 4) Return top-K by combined score
        refined.sort(key=lambda x: x[3], reverse=True)
        return refined[:top_k]
    
    def match_batch(self, khmer_queries: List[str], latin_queries: List[str] = None, 
                   top_k: int = 5, semantic_weight: float = 0.6, tfidf_weight: float = 0.2,
                   latin_weight: float = 0.5) -> Dict[str, List]:
        """
        Match multiple names in batch mode.
        
        Args:
            khmer_queries: List of Khmer names to match
            latin_queries: Optional list of Latin/English names (must be same length as khmer_queries)
            top_k: Number of results to return per query
            semantic_weight: Weight for semantic matching (0.0-1.0)
            tfidf_weight: Weight for TF-IDF matching (0.0-1.0)
            latin_weight: Weight for Latin matching vs Khmer matching (0.0-1.0)
            
        Returns:
            Dictionary mapping each query to its results
        """
        results = {}
        
        if latin_queries and len(khmer_queries) != len(latin_queries):
            raise ValueError(f"Length mismatch: {len(khmer_queries)} Khmer queries vs {len(latin_queries)} Latin queries")
        
        for i, khmer in enumerate(khmer_queries):
            # Get corresponding Latin name if available
            latin = ""
            if latin_queries and i < len(latin_queries):
                latin = latin_queries[i].strip()
            
            if latin and self.has_latin_names():
                results[khmer] = self.match_with_latin_fallback(
                    khmer, latin, top_k, semantic_weight, tfidf_weight, latin_weight
                )
            else:
                khmer_matches = self.hybrid_match(khmer, top_k, semantic_weight, tfidf_weight)
                results[khmer] = [
                    (name, score, self.get_latin_name(name), score, 0.0, self.get_name_frequency(name)) 
                    for name, score in khmer_matches
                ]
                
        return results


# Example usage
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Khmer Name Matcher CLI")
    parser.add_argument("--names", required=True, help="Path to names file")
    parser.add_argument("--khmer", required=True, help="Khmer name to match")
    parser.add_argument("--latin", help="Latin name to match (optional)")
    parser.add_argument("--top-k", type=int, default=5, help="Number of results")
    parser.add_argument("--semantic-weight", type=float, default=0.6, help="Semantic matching weight")
    parser.add_argument("--tfidf-weight", type=float, default=0.2, help="TF-IDF matching weight")
    parser.add_argument("--latin-weight", type=float, default=0.5, help="Latin matching weight")
    parser.add_argument("--index-dir", help="Directory to save/load indexes")
    parser.add_argument("--save-index", action="store_true", help="Save indexes after loading")
    
    args = parser.parse_args()
    
    # Create matcher
    matcher = KhmerNameMatcher(args.names, index_dir=args.index_dir)
    
    # Save index if requested
    if args.save_index and not args.index_dir:
        print("Warning: --save-index requires --index-dir. Indexes won't be saved.")
    elif args.save_index:
        matcher._save_indexes(args.names)
    
    # Match name
    if args.latin:
        results = matcher.match_with_latin_fallback(
            args.khmer, args.latin, args.top_k, args.semantic_weight, 
            args.tfidf_weight, args.latin_weight
        )
        
        # Print results
        print(f"\nMatching '{args.khmer}' (Latin: '{args.latin}'):")
        for khmer, khmer_score, latin, combined, latin_score, freq in results:
            print(f"- {khmer} (Latin: {latin})")
            print(f"  Khmer score: {khmer_score:.3f}, Latin score: {latin_score:.3f}")
            print(f"  Combined: {combined:.3f}, Frequency: {freq}")
    else:
        results = matcher.hybrid_match(args.khmer, args.top_k, args.semantic_weight, args.tfidf_weight)
        
        # Print results
        print(f"\nMatching '{args.khmer}':")
        for khmer, score in results:
            latin = matcher.get_latin_name(khmer)
            freq = matcher.get_name_frequency(khmer)
            print(f"- {khmer}" + (f" (Latin: {latin})" if latin else ""))
            print(f"  Score: {score:.3f}, Frequency: {freq}") 